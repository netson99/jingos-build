#ifndef JAPPLICATION_H
#define JAPPLICATION_H

#include <signal.h>
#include <list>

typedef void (*QUIT_FUN)(void);
typedef void (*CALLBACK_FUNC_TYPE)(void*);

struct ST_CALLBACK
{
    CALLBACK_FUNC_TYPE callback;
    void *data;
};
/**
 * @todo write docs
 */
class JApplication
{
public:
    JApplication();
    ~JApplication();
    int getConnectFd() { return connect_fd;}
    int receiveData(char *command, char *buffer, int buffer_size);
    int sendData(char command, char *data, int data_size);
    int sendPid();
    static void registerQuitFunction(QUIT_FUN function);
    void registerPauseCallBack(CALLBACK_FUNC_TYPE callback, void *data = nullptr);
    void registerResumeCallBack(CALLBACK_FUNC_TYPE callback, void *data = nullptr);
    void registerBackgroundCallBack(CALLBACK_FUNC_TYPE callback, void *data = nullptr);
    void unregisterPauseCallBack(CALLBACK_FUNC_TYPE callback);
    void unregisterResumeCallBack(CALLBACK_FUNC_TYPE callback);
    void unregisterBackgroundCallBack(CALLBACK_FUNC_TYPE callback);
    int receiveAndHandle();
    bool isBackgroudEnable() const;
    void enableBackgroud(bool enable);
private:
    void initConnection();
    void initSignalHandler();
    bool hasCallbackFunction(const std::list<ST_CALLBACK> &callbackList, CALLBACK_FUNC_TYPE callback);
    static void handleQuit(int);
private:
    int connect_fd;
    static QUIT_FUN m_quitFunction;
    std::list<ST_CALLBACK> m_pauseCallbacks;
    std::list<ST_CALLBACK> m_resumeCallbacks;
    std::list<ST_CALLBACK> m_backgroundCallbacks;
    static sighandler_t defaultSigHandler;
    char m_buffer[128];
    bool m_enableBackgroud;
};

#endif // JAPPLICATION_H
