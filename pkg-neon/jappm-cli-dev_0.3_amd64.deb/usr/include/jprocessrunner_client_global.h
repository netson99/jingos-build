#include <qt5/QtCore/QtGlobal>

#if defined(JPROCESSRUNNER_CLIENT_LIBRARY)
#  define JPROCESSRUNNER_CLIENT_EXPORT Q_DECL_EXPORT
#else
#  define JPROCESSRUNNER_CLIENT_EXPORT Q_DECL_IMPORT
#endif

class KProcessRunnerFactory;
extern "C" KProcessRunnerFactory * JPROCESSRUNNER_CLIENT_EXPORT createAppManagerClientProcessRunnerFactory();
