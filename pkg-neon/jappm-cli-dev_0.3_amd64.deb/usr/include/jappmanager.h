#ifndef JAPPMANAGER_H_INCLUDED
#define JAPPMANAGER_H_INCLUDED

#include<qt5/QtCore/QObject>
#include<qt5/QtCore/QString>
#include"jappm_global.h"

class ComJingosJappmanagerdInterface;

class JAPPM_CLI_EXPORT JAppManager : public QObject
{
public:
    JAppManager(QObject *parent = nullptr);
    int launch(const QString &desktop_id, const QStringList &args, const QStringList &env);
    int quit(const QString &desktop_id);
    int quitByPid(qint64 pid);
    int quitByWUuid(const QString &uuid);
    int pause(const QString &desktop_id);
    int pauseByPid(qint64 pid);
    int pauseByWUuid(const QString &uuid);
    int resume(const QString &desktop_id);
    int resumeByPid(qint64 pid);
    int resumeByWUuid(const QString &uuid);
    QString dump();
    bool appIsRunning(const QString &desktop_id);
    bool appIsRunningByPid(qint64 pid);
    bool appIsRunningByWUuid(const QString &uuid);
private:
    ComJingosJappmanagerdInterface *m_interface;
};
#endif // JAPPMANAGER_H_INCLUDED
