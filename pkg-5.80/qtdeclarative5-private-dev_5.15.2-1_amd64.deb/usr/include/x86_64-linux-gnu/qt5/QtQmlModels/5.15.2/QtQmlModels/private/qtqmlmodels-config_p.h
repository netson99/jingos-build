#define QT_FEATURE_qml_object_model 1
#define QT_FEATURE_qml_delegate_model 1
#define QT_FEATURE_qml_list_model 1
#define QT_FEATURE_qml_table_model 1
