# normally set by /etc/environment in ubuntu but that gets over wridden
# in touch and games gets removed
export PATH=$PATH:/usr/games:/usr/local/games
