#define QT_FEATURE_d3d12 -1
#define QT_FEATURE_quick_draganddrop 1
