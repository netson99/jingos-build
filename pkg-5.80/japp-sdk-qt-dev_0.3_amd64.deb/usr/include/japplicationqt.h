#ifndef JAPPLICATIONQT_H
#define JAPPLICATIONQT_H
#include <japplication.h>
#include <qt5/QtCore/QObject>
#include <qt5/QtCore/QSocketDescriptor>

class QSocketNotifier;
/**
 * @todo write docs
 */
class JApplicationQt : public QObject
{
    Q_OBJECT
public:
    JApplicationQt();
    virtual ~JApplicationQt();
    bool isBackgroudEnable() const;
    void enableBackgroud(bool enable);
    virtual void onPause();
    virtual void onResume();
    virtual void onBackground();
signals:
    void pause();
    void resume();
    void background();
private:
    static void quitJApp(void);
    static void pauseCallback(void *data);
    static void resumeCallback(void *data);
    static void backgroundCallback(void *data);
private:
    JApplication m_japp;
    QSocketNotifier *m_notifier;
};

#endif // JAPPLICATIONQT_H
