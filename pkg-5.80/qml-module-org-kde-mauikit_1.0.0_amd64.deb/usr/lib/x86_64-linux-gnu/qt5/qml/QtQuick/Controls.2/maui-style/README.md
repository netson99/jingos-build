# Nomad Qt Quick Controls 2 Style [![Build Status](https://travis-ci.org/nomad-desktop/qqc2-desktop-style-nomad.svg?branch=master)](https://travis-ci.org/nomad-desktop/qqc2-desktop-style-nomad)
Nomad Applications Theme for Qt Quick Controls 2.

# Issues
If you find problems with the contents of this repository please create an issue.

©2018 Nitrux Latinoamericana S.C.
