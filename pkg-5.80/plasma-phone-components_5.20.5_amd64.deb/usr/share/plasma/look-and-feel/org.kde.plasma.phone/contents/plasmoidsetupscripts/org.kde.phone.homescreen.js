applet.wallpaperPlugin = 'org.kde.image'
applet.writeConfig("AppOrder", ["org.kde.phone.dialer.desktop", "org.kde.phonebook.desktop", "org.kde.mobile.angelfish.desktop", "org.kde.mobile.camera.desktop"])
applet.writeConfig("Favorites", ["org.kde.phone.dialer.desktop", "org.kde.phonebook.desktop", "org.kde.mobile.angelfish.desktop", "org.kde.mobile.camera.desktop"])
applet.reloadConfig()

