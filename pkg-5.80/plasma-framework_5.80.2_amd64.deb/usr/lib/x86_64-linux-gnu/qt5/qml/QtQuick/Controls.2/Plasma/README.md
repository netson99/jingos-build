Plasma Components 3 is a style for QtQuick Controls 2.

It is exported as an import so users can force a theme, but it is also available just as a style.

This folder should only contain inherited templates from QQC2 desktop themes. There should be no new Components or properties.

New API should be in either upstream QQC2 itself, PlasmaExtras, or Kirigami.
